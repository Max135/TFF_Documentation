//
//  WindInfo.swift
//  TFF_App
//
//  Created by Mickael Salvas on 2020-12-07.
//

import Foundation

struct WindInfo : Codable {
    let value: String?
}
